const express = require("express");
const { addAnswer } = require("../Controllers/answerController");
const router = express.Router();

// router.post("/insert", addAnswer);

module.exports = router;
